export interface Language {
  TITLE: String;
  HOME: String;
  PRODUCTS: String;
  CONTACT: String;
  SIGNIN: String;
  MYACCOUNT: String;
  LOGOUT: String;
}
