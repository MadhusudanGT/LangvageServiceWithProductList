import { Component, OnInit } from "@angular/core";
import { Language } from "./models/language.model";
import { ChangeLanguageService } from "./services/change-language.service";
import { ProductMessengerService } from "./services/product-messenger.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"],
})
export class AppComponent implements OnInit {
  title = "sarvavastu-ui";

  selectedLanguage: any;
  preferredLanguage: String = "";
  _checkLanguage;

  constructor(
    private languageService: ChangeLanguageService,
    private cardService: ProductMessengerService
  ) {}

  ngOnInit() {
    this.languageService
      .selectLanguage(this.preferredLanguage)
      .then((data) => (this.selectedLanguage = data));
  }

  changeLanguage() {
    this.languageService
      .selectLanguage(this.preferredLanguage)
      .then((data) => (this.selectedLanguage = data));
  }

  checkLanguage() {
    console.log(this.languageService._selectedLanguage);
  }
}
